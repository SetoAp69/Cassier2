public class strukBelanja {
}
