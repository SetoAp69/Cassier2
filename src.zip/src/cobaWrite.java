import java.io.File;

public class cobaWrite {
    public static void main(String[] args) {
        File x=new File("D:\\x.txt");
        System.out.println(x.getName());
    }
}
